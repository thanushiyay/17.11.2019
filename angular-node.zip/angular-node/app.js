var express = require('express');
const _=require('lodash');
var path = require('path');
var cookieParser = require('cookie-parser');
// const mongoose=require('mongoose');
var bodyParser = require('body-parser');

// for mongo Db
const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost/SeeVoov', {useUnifiedTopology: true})
 .then(()=>console.log('Connected to Mongo Db....'))
 .catch(err=>console.error('Could not connect to Mongo Db',err));
// 	const dbpath = "mongodb://localhost:27017/SeeVoov";
// const mongo = mongoose.connect(dbpath, {useNewUrlParser: true });
// mongo.then(() => {
// console.log('connected');
// }).catch((err) => {
// console.log('err', err);
// });





var generate_uid = require('./routes/generate_uid');
var customer = require('./routes/customer');
var places_list=require('./routes/places_list');
// var places_diff_View=require('./routes/')
// var user=require('./routes/MainUser');




let reporter = function (type, ...rest)
{
	// remote reporter logic goes here
};

/* handle an uncaught exception & exit the process */
process.on('uncaughtException', function (err)
{
	console.error((new Date).toUTCString() + ' uncaughtException:', err.message);
	console.error(err.stack);

	reporter("uncaughtException", (new Date).toUTCString(), err.message, err.stack);

	process.exit(1);
});

/* handle an unhandled promise rejection */
process.on('unhandledRejection', function (reason, promise)
{
	console.error('unhandled rejection:', reason.message || reason);

	reporter("uncaughtException", (new Date).toUTCString(), reason.message || reason);
})

var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser())

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use('/api/v1/customer', customer);
app.use('/api/v1/generate_uid', generate_uid);
app.use('/api/v1/places_list',places_list);
// app.use('/api/v1/places_diff_View',places_diff_view);

module.exports = app;