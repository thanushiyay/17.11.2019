import { Component, OnInit } from '@angular/core';
import {MatDialog,MatDialogRef} from '@angular/material';
import { TermsDialogComponent } from '../terms-dialog/terms-dialog.component';
import { FormControl,FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DialogComponent } from '../dialog/dialog.component';
import { LoginService } from '../login.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { SigninDialogComponent } from '../signin-dialog/signin-dialog.component';
import {MatSnackBar} from '@angular/material/snack-bar';
import { MainServiceService } from '../main-service.service';
// import {FormControl, Validators} from '@angular/forms';
@Component({
  selector: 'app-create-dialog',
  templateUrl: './create-dialog.component.html',
  styleUrls: ['./create-dialog.component.css']
})
export class CreateDialogComponent implements OnInit {

  myRecaptcha=new FormControl(false);
  guid: string;
  submitted: boolean;
  serviceErrors: any={}
  constructor(public dialog:MatDialog,private fb:FormBuilder,
    private _loginService:LoginService,
    private dialogRef:MatDialogRef<CreateDialogComponent>,
    private http: HttpClient,
    private router:Router,
    private _snackBar:MatSnackBar,
    private  _mainService:MainServiceService) 
   {}
  authError:any;
  myform:FormGroup;
  ngOnInit()
  {
      
     this.myform=this.fb.group(
       {
             firstName:['',[Validators.required,Validators.minLength(4)]],
             lastName:['',[Validators.required,Validators.minLength(4)]],
             email:['',[Validators.required,Validators.minLength(4),Validators.email]],
             password:['',[Validators.required,Validators.minLength(6),Validators.pattern('^[a-zA-Z0-9]+$')]],
             check:['',[Validators.required]]
       }
     );
  }
  onSubmit(form: { value: any; }):void
  {
     this.submitted = true;
  	if(this.myform.invalid == true)
  	{
  		return;
  	}
  	else
  	{
      alert("Hiii registering....!!!!!!!!!!");
      alert(this.myform.value);
  		let data: any = Object.assign(this.myform.value);
      alert(data.firstName);
  		this.http.post('/api/v1/customer', data).subscribe((data:any) => {

        // this._mainService.setUser(data.firstName);
         alert(data.firstName);
         this.openSnackBar(data.firstName);
         this.dialogRef.close();
         setTimeout(()=>{
         
          this.dialog.open(SigninDialogComponent,{disableClose:true});

         },3800);
         
	    }, error =>
	    {
	    	this.serviceErrors = error.error.error;
        });
  	}
  }


      // Recaptcha
  onScriptLoad()
  {
    console.log("Google recaptch is ready for use");
  }
  onScriptError()
  {
     console.log("Something went wrong");
  }
  
  // goBack
  goBack()
  {
    this.dialogRef.close();
    this.dialog.open(DialogComponent,{disableClose:true});
  }

  OpenDialog()
  {
    this.dialog.open(TermsDialogComponent);
  }
  openSnackBar(firstName:string)
  {
    this._snackBar.open('Successfully Registered',firstName,{
      duration:2000,
      verticalPosition: 'top'
    });
  }

}
