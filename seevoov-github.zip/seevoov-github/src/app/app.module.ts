import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatVideoModule } from 'mat-video';
// import 'hammerjs';
import { NgModule } from '@angular/core';
//  npm i angular-animations --saveimport { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSelectModule } from '@angular/material/select';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatDialogModule, MatFormFieldModule,MatInputModule } from '@angular/material';
// import {MatSidenavModule} from '@angular/material/sidenav';
// import {MatButtonModule} from '@angular/material';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatButtonModule, MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule, MatToolbarModule } from '@angular/material';
import { DialogComponent } from './dialog/dialog.component';
import { TermsDialogComponent } from './terms-dialog/terms-dialog.component';
import { AboutComponent } from './about/about.component';
import { CareersComponent } from './careers/careers.component';
import { AffiliatesComponent } from './affiliates/affiliates.component';
import { TermsConditionsComponent } from './terms-conditions/terms-conditions.component';
import { ContactComponent } from './contact/contact.component';
import { IgxCalendarModule } from 'igniteui-angular';
import {FullCalendarModule} from '@fullcalendar/angular';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MainDialogComponent } from './main-dialog/main-dialog.component';
import { MainServiceService } from './main-service.service';
import { CreateDialogComponent } from './create-dialog/create-dialog.component';
import {MatRadioModule} from '@angular/material/radio';

// import {RecaptchaModule} from 'ng-recaptcha';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {ReactiveFormsModule} from '@angular/forms';
import  {RecaptchaModule} from 'angular-google-recaptcha';
import { YoutubeDialogComponent } from './youtube-dialog/youtube-dialog.component';
// import { Ng2GoogleRecaptchaModule } from 'ng2-google-recaptcha';
//import {MatFormFieldModule} from '@angular/material/form-field';

//authentication
import {environment} from '../environments/environment';
// import {AngularFireModule} from '@angular/fire';
// import {AngularFireAuthModule} from '@angular/fire/auth';
// import {AngularFirestoreModule} from '@angular/fire/firestore';

//PERFECT-SCROLLBAR
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
//ngSearch Bar
import { NgMatSearchBarModule } from 'ng-mat-search-bar';
// import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { interval } from 'rxjs';
import { Title }     from '@angular/platform-browser';
//star rating
import { RatingModule } from 'ng-starrating';
import { OwlModule } from 'ngx-owl-carousel';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { PopUpDialogComponent } from './pop-up-dialog/pop-up-dialog.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import { TripDialogComponent } from './trip-dialog/trip-dialog.component';
// import {MatSnackBar} from '@angular/material/snack-bar';
import {MatSnackBarModule} from '@angular/material/snack-bar';
//date

// import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { DateRangePickerModule } from '@syncfusion/ej2-angular-calendars';
import { SigninDialogComponent } from './signin-dialog/signin-dialog.component';
// import { DisplayUserDataComponentComponent } from './display-user-data-component/display-user-data-component.component';
import { LoginService } from './login.service';

import {HttpClientModule}  from    '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    DialogComponent,
    TermsDialogComponent,
    AboutComponent, 
    CareersComponent,
    AffiliatesComponent,
    TermsConditionsComponent,
    ContactComponent,
    MainDialogComponent,
    CreateDialogComponent,
    YoutubeDialogComponent,
    PopUpDialogComponent,
    TripDialogComponent,
    SigninDialogComponent
    // DisplayUserDataComponentComponent
   
    // DateRangePickerModule
  ],
  entryComponents: [DialogComponent, TermsDialogComponent,MainDialogComponent,
    CreateDialogComponent,YoutubeDialogComponent,PopUpDialogComponent,TripDialogComponent,SigninDialogComponent],
  imports: [
    BrowserModule,
    MatSelectModule,
    // AngularFirestoreModule,
    MatCheckboxModule,
    MatSnackBarModule,
    MatTooltipModule,
    HttpClientModule,
    NgMatSearchBarModule,
    NgxMatSelectSearchModule,
    NgbPaginationModule, NgbAlertModule,
    OwlModule,
    CarouselModule,
    RatingModule,
    PerfectScrollbarModule,
   // Ng2GoogleRecaptchaModule,
    NgbModule,
    MatRadioModule,
    // AngularFireModule.initializeApp(environment.firebase),
    // AngularFireAuthModule,
    // environment,
    RecaptchaModule.forRoot(
      {
        siteKey:'6LcCzLgUAAAAAOHa-P2fFSE5kqhRrNZ38cQzAsw6',
      }
    ),
    FlexLayoutModule,
    MatInputModule,
    FullCalendarModule,
    MatVideoModule,
    MatProgressSpinnerModule,
    ReactiveFormsModule,
    MatDialogModule,
    // BsDatepickerModule.forRoot(),
    DateRangePickerModule,
    // MatDialogConfig,
    FormsModule,
    MatFormFieldModule,
    AppRoutingModule,
    MatButtonModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule, MatToolbarModule,
    IgxCalendarModule

  ],
  providers: [MainServiceService,LoginService,{
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
  },
  Title
                  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
